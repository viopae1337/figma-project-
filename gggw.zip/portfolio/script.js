// Мобильное меню: открыть / закрыть по кнопке-бургеру
const toggle = document.querySelector(".navbar__toggle");
const menu = document.querySelector("#menu");

toggle.addEventListener("click", () => {
  const isOpen = menu.classList.toggle("is-open");
  toggle.setAttribute("aria-expanded", String(isOpen));
});

// Закрываем меню после клика по ссылке
menu.addEventListener("click", (event) => {
  if (event.target.closest("a")) {
    menu.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
  }
});
