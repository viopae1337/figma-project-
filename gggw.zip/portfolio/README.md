# Kyle — Simple Portfolio (HTML + CSS)

Файлы: `index.html`, `style.css`, `script.js` (только бургер-меню), папка `images/`.
Шрифты Sansation и Nunito подключаются из Google Fonts (нужен интернет).
Свои данные: тексты в `index.html`, фото — заменить `images/hero.png` и `images/about.png`.
